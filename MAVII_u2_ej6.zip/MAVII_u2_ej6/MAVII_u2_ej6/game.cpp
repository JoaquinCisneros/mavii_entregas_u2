#include "Game.h"
#include "Box2DHelper.h"
#include <iostream>

// Constructor de la clase Game
Game::Game(int ancho, int alto, std::string titulo)
{
    // Inicializaci�n de la ventana y configuraci�n de propiedades
    wnd = new RenderWindow(VideoMode(ancho, alto), titulo);
    wnd->setVisible(true);
    fps = 60;
    wnd->setFramerateLimit(fps);
    frameTime = 1.0f / fps;
    SetZoom(); // Configuraci�n de la vista del juego
    InitPhysics(); // Inicializaci�n del motor de f�sica
}

// Bucle principal del juego
void Game::Loop()
{
    while (wnd->isOpen())
    {
        wnd->clear(clearColor); // Limpiar la ventana
        DoEvents(); // Procesar eventos de entrada
        CheckCollitions(); // Comprobar colisiones
        UpdatePhysics(); // Actualizar la simulaci�n f�sica
        DrawGame(); // Dibujar el juego
        wnd->display(); // Mostrar la ventana
    }
}

// Actualizaci�n de la simulaci�n f�sica
void Game::UpdatePhysics()
{
    phyWorld->Step(frameTime, 8, 8); // Simular el mundo f�sico
    phyWorld->ClearForces(); // Limpiar las fuerzas aplicadas a los cuerpos
    phyWorld->DebugDraw(); // Dibujar el mundo f�sico para depuraci�n
}

// Dibujo de los elementos del juego
void Game::DrawGame()
{
    //dibujo el ca�on
    sf::RectangleShape canyon(sf::Vector2f(15.0f, 8.0f));
    canyon.setFillColor(sf::Color::Red);
    canyon.setPosition(canyonBody->GetPosition().x, canyonBody->GetPosition().y);
    canyon.setOrigin(7.5f, 4.0f);

    //ajusto el angulo para que coincida con el body

    float angleInRadians = canyonBody->GetAngle();
    canyon.setRotation(angleInRadians * 180 / b2_pi);

    wnd->draw(canyon);

}

// Procesamiento de eventos de entrada
void Game::DoEvents()
{
    Event evt;
    while (wnd->pollEvent(evt))
    {
        switch (evt.type)
        {
        case Event::Closed:
            wnd->close(); // Cerrar la ventana si se presiona el bot�n de cerrar
            break;
        case Event::KeyPressed:
            if (evt.key.code == Keyboard::Left) {
            //inclinar hacia la izquierda
                    canyonBody->SetTransform(canyonBody->GetPosition(), canyonBody->GetAngle() - 0.02f);
            }
            else if (evt.key.code == Keyboard::Right) {
            //inclinar hacia la derecha
                    canyonBody->SetTransform(canyonBody->GetPosition(), canyonBody->GetAngle() + 0.02f);
            }
            break;
        case Event::MouseButtonPressed:
            //Crear un cuerpo dinamico proyectil
            b2Body* proyectile = Box2DHelper::CreateRectangularDynamicBody(phyWorld, 1.0f, 1.0f, 1.0f, 0.1f, 0.2f);
            //posicionar segun el angulo del ca�on
            proyectile->SetTransform(b2Vec2(canyonBody->GetPosition().x, canyonBody->GetPosition().y), canyonBody->GetAngle());
            //impulsar el proyectil
            proyectile->ApplyLinearImpulseToCenter(b2Vec2(100.0f, 0.0f), true);
        }
    }
}

// Comprobaci�n de colisiones (a implementar m�s adelante)
void Game::CheckCollitions()
{
    // Implementaci�n de la comprobaci�n de colisiones
}

// Configuraci�n de la vista del juego
void Game::SetZoom()
{
    View camara;
    // Posicionamiento y tama�o de la vista
    camara.setSize(100.0f, 100.0f);
    camara.setCenter(50.0f, 50.0f);
    wnd->setView(camara); // Asignar la vista a la ventana
}

// Inicializaci�n del motor de f�sica y los cuerpos del mundo f�sico
void Game::InitPhysics()
{
    // Inicializar el mundo f�sico con la gravedad por defecto
    phyWorld = new b2World(b2Vec2(0.0f, 9.8f));

    // Crear un renderer de debug para visualizar el mundo f�sico
    debugRender = new SFMLRenderer(wnd);
    debugRender->SetFlags(UINT_MAX);
    phyWorld->SetDebugDraw(debugRender);

    // Crear el suelo y las paredes est�ticas del mundo f�sico

    b2Body* groundBody = Box2DHelper::CreateRectangularStaticBody(phyWorld, 100, 10);
    groundBody->SetTransform(b2Vec2(50.0f, 100.0f), 0.0f);

    //Crear plataformas estaticas para los objetivos

    b2Body* plataform1 = Box2DHelper::CreateRectangularStaticBody(phyWorld, 3, 1);
    plataform1->SetTransform(b2Vec2(85.0f, 15.0f), 0.0f);

    b2Body* plataform2 = Box2DHelper::CreateRectangularStaticBody(phyWorld, 3, 1);
    plataform2->SetTransform(b2Vec2(85.0f, 45.0f), 0.0f);

    b2Body* plataform3 = Box2DHelper::CreateRectangularStaticBody(phyWorld, 3, 1);
    plataform3->SetTransform(b2Vec2(85.0f, 75.0f), 0.0f);

    //Setear body del ca�on

    canyonBody = Box2DHelper::CreateRectangularKinematicBody(phyWorld, 15.0f, 8.0f);
    float angle = 0.0f;
    float angleToRadiansBody = angle * 180 / b2_pi;
    canyonBody->SetTransform(b2Vec2(15.0f, 85.0f), angleToRadiansBody);

    //fisicas de los objetivos

    b2Body* objective1 = Box2DHelper::CreateRectangularDynamicBody(phyWorld, 1.0f, 4.0f, 1.0f, 0.1f, 0.0f);
    objective1->SetTransform(b2Vec2(85.0f, 14.0f), 0.0f);

    b2Body* objective2 = Box2DHelper::CreateRectangularDynamicBody(phyWorld, 1.0f, 4.0f, 1.0f, 0.1f, 0.0f);
    objective2->SetTransform(b2Vec2(85.0f, 44.0f), 0.0f);

    b2Body* objective3 = Box2DHelper::CreateRectangularDynamicBody(phyWorld, 1.0f, 4.0f, 1.0f, 0.1f, 0.0f);
    objective3->SetTransform(b2Vec2(85.0f, 74.0f), 0.0f);

}

// Destructor de la clase

Game::~Game(void)
{ }