#include "Game.h"
#include <iostream>

using namespace std;
using namespace sf;

int main() {

	Game myGame(800, 600, "Ventanita");
	myGame.Loop();

	return 0;
}