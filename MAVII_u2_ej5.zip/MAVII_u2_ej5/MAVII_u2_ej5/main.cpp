#include "game.h"
using namespace std;
using namespace sf;

int main() {

	Game myGame(800, 600, "Titulo de ventana");
	myGame.Loop();


	return 0;
}