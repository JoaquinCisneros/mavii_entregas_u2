#include "game.h"
#include <iostream>

using namespace sf;
using namespace std;

int main() {

	Game myGame(800, 600, "Titulo");
	myGame.Loop();

	return 0;
}